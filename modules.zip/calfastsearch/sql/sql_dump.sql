
CREATE TABLE `ps_project` (
  `id_project` int(11) UNSIGNED NOT NULL,
  `Name` varchar(50) NOT NULL DEFAULT ' ',
  `cost` decimal(10,2) DEFAULT '0.00',
  `duration` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ps_project`
--

INSERT INTO `ps_project` (`id_project`, `Name`, `cost`, `duration`) VALUES
(1, 'Product', '130.65', 5),
(3, 'Product 2', '124.89', 4),
(4, 'Product 7', '12.90', 5),
(5, 'product 10', '34.90', 8);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ps_project`
--
ALTER TABLE `ps_project`
  ADD PRIMARY KEY (`id_project`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ps_project`
--
ALTER TABLE `ps_project`
  MODIFY `id_project` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
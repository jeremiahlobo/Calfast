<?php
require_once './config/settings.inc.php';
require_once './config/defines.inc.php';
require_once './config/config.inc.php';

class CalsearchModel extends ObjectModel
{
	
	public function CleanString($string)
	{
		return preg_replace("/[^a-zA-Z0-9]/", "", $string);
	}
	 
	public function getSearch($searchword)
	{

		$connection = mysqli_connect(_DB_SERVER_,_DB_USER_,_DB_PASSWD_) or die(mysqli_error());
		mysqli_select_db($connection,_DB_NAME_) or die(mysql_error());
		$query = "SELECT `Name`, `cost`, `duration` FROM "._DB_PREFIX_."project WHERE `name`='%".$this->CleanString($searchword)."'%";
		$result = Db::getInstance()->getRow($query);
		
		return $result;
	}

}

/* file path: modules/calfastsearch/model/CalSearchModel.php*/
?>